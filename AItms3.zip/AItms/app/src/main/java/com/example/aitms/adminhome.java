package com.example.aitms;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.Toast;

import com.hitomi.cmlibrary.CircleMenu;
import com.hitomi.cmlibrary.OnMenuSelectedListener;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class adminhome extends AppCompatActivity {
    GridLayout mainGrid;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.adminhome);
        mainGrid=(GridLayout)findViewById(R.id.mainGrid);
        setSingleEvent(mainGrid);

        CircleMenu circleMenu = findViewById(R.id.circlemenu);
        final String[] menus = {
                "Add Driver",
                "Logout"
        };

        circleMenu.setMainMenu(Color.parseColor("#CDCDCD"),R.drawable.ic_add_black_24dp,R.drawable.ic_close_black_24dp)
                .addSubMenu(Color.parseColor("#00CD00"),R.drawable.ic_driver_add_black_24dp)
                .addSubMenu(Color.parseColor("#00CD00"),R.drawable.ic_exit_to_app_black_24dp)
                .setOnMenuSelectedListener(new OnMenuSelectedListener() {
                    @Override
                    public void onMenuSelected(int i) {
                        Toast.makeText(adminhome.this," "+ menus[i],Toast.LENGTH_SHORT).show();
                        switch (i){
                            case 0: startActivity(new Intent(adminhome.this, driverregister.class));break;
                            case 1: startActivity(new Intent(adminhome.this,adminlogin.class));break;
                        }
                    }

                });

    }

    private void setSingleEvent(GridLayout mainGrid) {
        for(int i=0;i<mainGrid.getChildCount();i++)
        {
            CardView cardView = (CardView)mainGrid.getChildAt(i);
            final int finalI = i;
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(adminhome.this, "Clicked at Dustbin" + finalI,Toast.LENGTH_SHORT ).show();


                }
            });
            {

            }
        }
    }
}
