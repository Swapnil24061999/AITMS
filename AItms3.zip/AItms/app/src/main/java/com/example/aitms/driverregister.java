package com.example.aitms;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class driverregister extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registerdriver);
        Button btn = (Button) findViewById(R.id.driverloginbtn);
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getBaseContext(),"Driver Registered Successfully!",Toast.LENGTH_SHORT).show();
            }
        };
        btn.setOnClickListener(listener);
    }
}
