package com.example.aitms;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class driverlogin extends AppCompatActivity {
        Button newbtn;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.logindriver);
            Button driverloginbtn = (Button)findViewById(R.id.driverloginbtn);
            driverloginbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent loginintent1=new Intent(driverlogin.this,driverhome.class);
                    startActivity(loginintent1);

                }
            });
    }

}
