package com.example.aitms;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class driverlogin extends AppCompatActivity {
    Button newbtn;
    EditText txtEmail, txtPassword;
    Button btn_login;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.logindriver);
        final Button driverloginbtn = (Button) findViewById(R.id.driverloginbtn);
        driverloginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent loginintent1 = new Intent(driverlogin.this, driverhome.class);
                startActivity(loginintent1);
                txtEmail = findViewById(R.id.driverlun);
                txtPassword = findViewById(R.id.driverlps);
                btn_login = findViewById(R.id.driverloginbtn);

                firebaseAuth = FirebaseAuth.getInstance();

                btn_login.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String email = txtEmail.getText().toString().trim();
                        String password = txtPassword.getText().toString().trim();

                        if (TextUtils.isEmpty(email)) {
                            Toast.makeText(driverlogin.this, "Please Enter Email", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        if (TextUtils.isEmpty(password)) {
                            Toast.makeText(driverlogin.this, "Please Enter Password", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        if (password.length() < 6) {
                            Toast.makeText(driverlogin.this, "Password too short", Toast.LENGTH_SHORT).show();
                        }

                        firebaseAuth.signInWithEmailAndPassword(email, password)
                                .addOnCompleteListener(driverlogin.this, new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                        if (task.isSuccessful()) {
                                            startActivity(new Intent(getApplicationContext(),driverhome.class));

                                        } else {
                                            Toast.makeText(driverlogin.this,"Login Failed or User Not Found",Toast.LENGTH_SHORT).show();
                                        }

                                        // ...
                                    }
                                });

                    }
                });
            }
        });

    }


}
