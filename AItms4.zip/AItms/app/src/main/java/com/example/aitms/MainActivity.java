package com.example.aitms;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.pusher.pushnotifications.PushNotifications;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private static int SPLASH_TIME_OUT=4000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        PushNotifications.start(getApplicationContext(), "9b961acc-94c7-4230-8da8-1d63df0856f0");
        PushNotifications.addDeviceInterest("hello");
        new Handler().postDelayed(new Runnable(){

            @Override
            public void run() {
                Intent homeIntent = new Intent(MainActivity.this,home.class);
                startActivity(homeIntent);
                finish();
            }
        },SPLASH_TIME_OUT);
    }
}
