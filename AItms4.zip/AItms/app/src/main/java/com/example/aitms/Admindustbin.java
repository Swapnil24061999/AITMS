package com.example.aitms;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class Admindustbin extends AppCompatActivity {
    ImageButton mapbtn;
    TextView distance;
    DatabaseReference dref;
    String Status;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admindustbin);

        distance = (TextView) findViewById(R.id.dist);
        dref = FirebaseDatabase.getInstance().getReference();
        dref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Status = dataSnapshot.child("distance").getValue().toString();
                distance.setText(Status);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        ImageButton driverlogout = (ImageButton)findViewById(R.id.adminmap);
        driverlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent logoutintent1=new Intent(Admindustbin.this,AdminMapsActivity.class);
                startActivity(logoutintent1);

            }
        });
    }
}
