package com.example.aitms;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.regex.Pattern;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class driverregister extends AppCompatActivity {

    EditText txtEmail, txtPassword, txtnumber;
    Button driverregbtn;
    FirebaseAuth firebaseAuth;
    DatabaseReference databaseReference;
    FirebaseDatabase firebaseDatabase;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registerdriver);
        Button btn = (Button) findViewById(R.id.driverregbtn);
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getBaseContext(),"Driver Registered Successfully!",Toast.LENGTH_SHORT).show();
            }
        };
        btn.setOnClickListener(listener);
        txtEmail = (EditText)findViewById(R.id.driverun);
        txtPassword = (EditText)findViewById(R.id.driverps);
        txtnumber = (EditText)findViewById(R.id.drivernum);
        driverregbtn = (Button)findViewById(R.id.driverregbtn);


        databaseReference = FirebaseDatabase.getInstance().getReference("driverInfo");

        firebaseAuth = FirebaseAuth.getInstance();

        driverregbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String email = txtEmail.getText().toString().trim();
                final String password = txtPassword.getText().toString().trim();
                String number = txtnumber.getText().toString().trim();

                if (TextUtils.isEmpty(email)){
                    Toast.makeText(driverregister.this, "Please Enter Email", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(password)){
                    Toast.makeText(driverregister.this, "Please Enter Password", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(number)){
                    Toast.makeText(driverregister.this, "Please Enter Number", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (password.length()<6){
                    Toast.makeText(driverregister.this, "Password too short", Toast.LENGTH_SHORT).show();
                }

                if (password.equals(password)){
                    firebaseAuth.createUserWithEmailAndPassword(email, password)
                            .addOnCompleteListener(driverregister.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        driverinfo driverinfo = new driverinfo(
                                                txtEmail,
                                                txtPassword,
                                                txtnumber
                                        );

                                        FirebaseDatabase.getInstance().getReference("DriverInfo")
                                                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                                .setValue(driverinfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                Toast.makeText(driverregister.this,"Registration Complete",Toast.LENGTH_SHORT).show();
                                                startActivity(new Intent(getApplicationContext(),adminhome.class));
                                            }
                                        });
                                    } else {
                                        Toast.makeText(driverregister.this,"Authentication Failed",Toast.LENGTH_SHORT).show();

                                    }

                                    // ...
                                }
                            });
                }
            }

        });

    }
}
