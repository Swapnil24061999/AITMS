package com.example.aitms;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class driverhome extends AppCompatActivity {
    GridLayout mainGrid;
    ImageButton btn;
    TextView dbst;
    DatabaseReference dref;
    String Status;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.driverhome);
        mainGrid=(GridLayout)findViewById(R.id.mainGrid);
        setSingleEvent(mainGrid);

        ImageButton driverlogout = (ImageButton)findViewById(R.id.logout);
        driverlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent logoutintent1=new Intent(driverhome.this,driverlogin.class);
                startActivity(logoutintent1);

            }
        });

        dbst = (TextView) findViewById(R.id.driverhomedb1);

        dref = FirebaseDatabase.getInstance().getReference();
        dref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Status = dataSnapshot.child("message").getValue().toString();
                dbst.setText(Status);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        

    }

    private void setSingleEvent(GridLayout mainGrid) {
        for(int i=0;i<mainGrid.getChildCount();i++)
        {
            CardView cardView = (CardView)mainGrid.getChildAt(i);
            final int finalI = i;
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (finalI == 0) {
                        Intent intent3 = new Intent(driverhome.this, Admindustbin.class);
                        startActivity(intent3);
                    } else {
                        Toast.makeText(driverhome.this, "Clicked at Dustbin" + finalI, Toast.LENGTH_SHORT).show();
                    }
                }

            });


        }
    }
}
