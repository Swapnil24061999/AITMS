package com.example.aitms;

import android.widget.EditText;

public class driverinfo {
    public String Email,Password,Number;

    public driverinfo(EditText txtEmail, EditText txtPassword, EditText txtnumber){


    }

    public driverinfo(String Email, String Password, String Number){
        this.Email = Email;
        this.Password = Password;
        this.Number = Number;

    }
}
