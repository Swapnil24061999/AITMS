package com.example.aitms;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.hitomi.cmlibrary.CircleMenu;
import com.hitomi.cmlibrary.OnMenuSelectedListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class adminhome extends AppCompatActivity {
    GridLayout mainGrid;
    TextView ast;
    DatabaseReference dref;
    String Status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.adminhome);
        ast = (TextView) findViewById(R.id.adminhomedb1);
        dref = FirebaseDatabase.getInstance().getReference();
        dref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Status = dataSnapshot.child("message").getValue().toString();
                ast.setText(Status);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mainGrid = (GridLayout) findViewById(R.id.mainGrid);
        setSingleEvent(mainGrid);

        CircleMenu circleMenu = findViewById(R.id.circlemenu);
        final String[] menus = {
                "Add Driver",
                "Logout"
        };

        circleMenu.setMainMenu(Color.parseColor("#CDCDCD"), R.drawable.ic_add_black_24dp, R.drawable.ic_close_black_24dp)
                .addSubMenu(Color.parseColor("#00CD00"), R.drawable.ic_driver_add_black_24dp)
                .addSubMenu(Color.parseColor("#00CD00"), R.drawable.ic_exit_to_app_black_24dp)
                .setOnMenuSelectedListener(new OnMenuSelectedListener() {
                    @Override
                    public void onMenuSelected(int i) {
                        Toast.makeText(adminhome.this, " " + menus[i], Toast.LENGTH_SHORT).show();
                        switch (i) {
                            case 0:
                                startActivity(new Intent(adminhome.this, driverregister.class));
                                break;
                            case 1:
                                startActivity(new Intent(adminhome.this, adminlogin.class));
                                break;
                        }
                    }

                });

    }

    private void setSingleEvent(GridLayout mainGrid) {
        for (int i = 0; i < mainGrid.getChildCount(); i++) {
            CardView cardView = (CardView) mainGrid.getChildAt(i);
            final int finalI = i;
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (finalI == 0)
                    {
                        Intent intent3 = new Intent(adminhome.this, Admindustbin.class);
                        startActivity(intent3);
                    }
                    else
                        {
                        Toast.makeText(adminhome.this, "Clicked at Dustbin" + finalI, Toast.LENGTH_SHORT).show();
                        }
                }

            });
        }
    }




}
