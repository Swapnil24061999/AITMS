package com.example.aitms;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class adminlogin extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loginadmin);
    }
}
